package com.example.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText e1,e2;
    TextView tv1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1=(EditText)findViewById(R.id.editText1);
        e1=(EditText)findViewById(R.id.editText2);
        tv1=(TextView)findViewById(R.id.textView);
    }
    public void doAdd(View V){
        float a1=Float.parseFloat(e1.getText().toString());
        float a2=Float.parseFloat(e2.getText().toString());
        float result=a1+a2;
        tv1.setText(" "+result);
    }
    public void doSub(View V){
        float a1=Float.parseFloat(e1.getText().toString());
        float a2=Float.parseFloat(e2.getText().toString());
        float result=a1-a2;
        tv1.setText(" "+result);
    }
    public void doMul(View V){
        float a1=Float.parseFloat(e1.getText().toString());
        float a2=Float.parseFloat(e2.getText().toString());
        float result=a1*a2;
        tv1.setText(" "+result);
    }
    public void doDiv(View V){
        float a1=Float.parseFloat(e1.getText().toString());
        float a2=Float.parseFloat(e2.getText().toString());
        float result=a1/a2;
        tv1.setText(" "+result);
    }
}