package com.example.hrulab8;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText text;
    Button btnclear,btnsave,btncall;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text=findViewById(R.id.PhoneNumber);
        btncall=findViewById(R.id.btncall);
        btnclear=findViewById(R.id.btnclear);
        btnsave=findViewById(R.id.btnsave);

        btnclear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                text.setText("");
            }
        });

        btncall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String phonenumner=text.getText().toString();
                Intent myIntent=new Intent(Intent.ACTION_DIAL);
                myIntent.setData(Uri.parse("tel:"+phonenumner));
                startActivity(myIntent);
            }
        });

        btnsave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String phonenumber=text.getText().toString();
                Intent myIntent=new Intent(Intent.ACTION_INSERT);
                myIntent.setType(ContactsContract.Contacts.CONTENT_TYPE);
                myIntent.putExtra(ContactsContract.Intents.Insert.PHONE,phonenumber);
                startActivity(myIntent);

            }
        });
    }

    public void inputNumber(View V){
        Button btn=(Button)V;
        String digit= btn.getText().toString();
        String phoneNumber=text.getText().toString();
        text.setText(phoneNumber+digit);
    }
}